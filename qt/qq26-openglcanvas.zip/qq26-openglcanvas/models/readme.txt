The models in this folder are free for personal or commercial use from http://www.oyonale.com/modeles.php?lang=en&format=OBJ
2008-06-27
